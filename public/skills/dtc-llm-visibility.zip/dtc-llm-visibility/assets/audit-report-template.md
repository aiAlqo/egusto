# [Brand Name] — AI/LLM Visibility Audit

_Tested [date]. AI answers change over time — treat this as a snapshot, not a permanent score._

## Summary

2-4 sentences: is the brand currently showing up in AI answers for its category, roughly how
does it compare to the named competitors, and what's the single biggest driver of the gap (or
strength).

## What we tested

- Buyer queries tested (list the exact prompts used)
- Engines: which were live-tested directly vs. provided as a copy-paste block for the user to
  run themselves

## Findings: live-query results

For each query: was the brand mentioned, in what position/framing, what was said about it, what
competitors appeared, what the answer seemed to draw on.

## Findings: site audit

Walk through `references/audit-checklist.md` categories, but only report what's actually true of
the pages reviewed — call out specific pages and specific gaps, not generic statements.

## Roadmap

Grouped by horizon:

### This week
(low-effort, high-leverage fixes)

### This quarter
(content builds, schema rollout, comparison pages)

### Ongoing
(PR, Reddit/community presence, review generation, tracking cadence)

## Next steps

What this audit doesn't cover / what to revisit, and when to rerun the tracker.
