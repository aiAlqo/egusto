---
name: dtc-llm-visibility
description: Helps direct-to-consumer (DTC) brands get found, cited, and recommended inside AI answers — ChatGPT, Claude, Perplexity, Gemini, and AI Overviews — not just traditional Google search. Use this whenever a user asks about "ranking on ChatGPT," "showing up in AI search," "getting recommended by AI," "GEO," "AEO," "AI SEO," "LLM visibility," "AI search optimization," or asks why a competitor gets mentioned by AI chatbots and they don't. Also trigger this for DTC/ecommerce brand owners or marketers who want an audit of their AI visibility, want AI-optimized product/FAQ/comparison content written, want a tracker to monitor brand mentions across AI engines over time, or want a prioritized roadmap for AI search strategy — even if they just say something like "why doesn't ChatGPT recommend us" or "how do I get my products mentioned when people ask AI for recommendations."
---

# DTC LLM Visibility

## What this is actually about

Traditional SEO optimizes for a ranked list of blue links. LLM visibility ("GEO" — generative
engine optimization, sometimes called AEO) optimizes for something different: whether a model,
when a real buyer asks it a question, pulls your brand into the handful of things it actually
says out loud. There's no page two. Either the model mentions you or it doesn't, and if it does,
it's usually because it found a clean, well-supported, easy-to-lift answer somewhere — on your
site or on a third-party source it trusts.

For a DTC brand this matters more every quarter: people increasingly ask ChatGPT or Perplexity
"what's the best electrolyte powder that doesn't taste like chemicals" instead of googling it,
and a brand that isn't structured to be *understood and cited* by a model is invisible to that
entire channel, no matter how good its paid-search game is.

This skill covers four things a DTC brand typically wants, and most requests will touch two or
three of them at once:

1. **Audit** — how visible is the brand right now, and why or why not
2. **Content/assets** — draft the actual pages, FAQ blocks, comparison content, and structured
   data that close the gaps the audit finds
3. **Tracking** — a repeatable prompt test suite the brand can rerun to watch visibility change
   over time
4. **Strategy/roadmap** — a prioritized plan tying the above together

Don't try to do all four in one giant undifferentiated pass. Figure out what the user actually
wants (see below), and if it's ambiguous, ask — a founder asking "why doesn't ChatGPT recommend
us" wants an audit + explanation; a marketer who says "we need to fix this" wants the full
roadmap and probably content too.

## Step 0: Get oriented

Before doing anything, get the essentials. If the user hasn't given them, ask directly (don't
guess at a real company's positioning):

- Brand name, product category, and website URL
- Who the target buyer is and what they'd type/ask when shopping this category
- 2-4 real competitors (named competitors matter a lot here — GEO is comparative; the model is
  often choosing *between* brands when it answers)
- What's already been tried, if anything (a past SEO push, PR, Reddit seeding, etc.)

Skip re-asking anything already given in the conversation.

## Step 1: Run the visibility audit

This is almost always the right starting point, even if the user asked for content or a roadmap
outright — you need to know the actual gaps before prescribing fixes for them.

**A. Live-query test.** Take 8-12 realistic buyer questions in the brand's category — the kind
of thing an actual shopper asks, not brand-name searches. Mix intents: broad recommendation
("what's the best X for Y"), comparison ("X vs Y vs Z"), and specific-need queries ("X for
[condition/use case]"). Ask each one yourself (you're an LLM — this is a live data point) and
record: does the brand appear, in what position/framing, what's said about it, and what sources
or reasoning the answer leans on. Since you can only directly query yourself, also write out the
exact same prompt list in a copy-pasteable block so the user can run it against ChatGPT,
Perplexity, and Gemini themselves within a few minutes — visibility genuinely differs by engine,
and a claim about "AI visibility" that's only tested on one model is weak evidence.

**B. Site/content audit.** Fetch the brand's homepage, 2-3 product pages, and FAQ/about pages if
they exist. Score them against `references/audit-checklist.md` — this covers answer-first
structure, FAQ presence and schema, comparison content, structured data, and third-party proof
signals. Read that file now if you haven't already; don't rely on memory for the checklist
criteria.

**C. Synthesize.** Combine A and B into findings, not just a checklist score. The useful output
isn't "you're missing FAQ schema" — it's "when we asked 'best recovery drink for athletes,' the
model named two competitors by name and never mentioned you, and your product pages don't
actually answer any of the comparison questions a buyer would ask, which is consistent with why."
Tie every finding back to a specific query result or page gap; vague GEO advice generalized from
nowhere is not useful to this brand specifically.

Write this up as an audit report (use the `docx` skill for a polished deliverable, unless the
user clearly just wants a quick answer in chat). Structure per
`assets/audit-report-template.md`.

## Step 2: Prioritized roadmap

Rank the fixes by leverage: what closes the biggest, most-repeated gap from Step 1 for the least
effort. `references/geo-tactics-dtc.md` has the full tactical playbook (content structure,
technical/schema requirements, third-party citation building, comparison content, measurement) —
read it before writing recommendations so the roadmap draws on the full tactic set rather than
just the two or three most obvious ones. Group recommendations into rough horizons (do this
week / this quarter / ongoing) rather than a flat list — DTC teams are usually small and need to
know what to do Monday morning, not just what's ideal in principle.

## Step 3: Build content/assets (when asked, or when the roadmap calls for it)

The highest-leverage assets are usually, in order: FAQ content answering the exact buyer
questions from the Step 1 live-query test (these can lift almost verbatim into an AI answer if
well-written), comparison pages against the named competitors, and structured data
(Product/FAQPage/Review schema) on top of pages that already have good content but aren't marked
up. `references/geo-tactics-dtc.md` has format guidance and a schema markup example for each.
Write real content specific to this brand's actual products and claims — never invent product
specs, certifications, or review counts; ask the user for the real numbers/claims if they matter
to the content and weren't provided.

## Step 4: Set up ongoing tracking

GEO visibility drifts — models update, competitors publish, answers change week to week — so a
one-time audit goes stale. Build a reusable tracker rather than a one-off list:

```bash
python scripts/build_tracker.py --brand "BrandName" --category "electrolyte powders" \
  --competitors "Competitor A,Competitor B,Competitor C" --output tracker.csv
```

This generates a CSV of buyer-intent test prompts (seeded from the same query patterns used in
Step 1, so the tracker and the audit stay consistent) with columns for engine, mentioned (y/n),
position/framing, and date — ready to hand to the `xlsx` skill to turn into a spreadsheet the
brand can open monthly and refill by hand or with a teammate. Explain the cadence: monthly is
usually enough for a small DTC team; don't oversell automated monitoring that doesn't exist here
— this produces the test suite, not a live scraper. If the user wants full automation, say so
plainly rather than implying the tracker updates itself.

## Notes on doing this well

Resist the urge to produce generic GEO advice ("add FAQ schema," "get on Reddit") without
grounding it in what Step 1 actually found for *this* brand. Two brands in the same category can
have completely different gaps — one might have great content but zero third-party citations,
another might have citations everywhere but pages the model can't parse into a clean answer. The
value of this skill is doing the diagnostic work, not reciting the same playbook regardless of
input.

Also be honest about what's uncertain. Model behavior changes, and a single live-query test is a
sample of one moment, not a guarantee. Frame audit findings as "as tested on [date]" and
encourage rerunning the tracker rather than treating one audit as permanent truth.
