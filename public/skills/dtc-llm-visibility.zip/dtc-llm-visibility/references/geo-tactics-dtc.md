# GEO tactics for DTC brands

A reference playbook of concrete tactics. Pull from this when writing roadmap recommendations
or drafting content — don't just recite section headers, apply the specific guidance to the
brand's actual gaps.

## 1. Answer-first content structure

Models tend to lift the part of a page that most directly and completely answers a question,
usually early in the content. For any page meant to be a citation source:

- Answer the core question in the first ~150-200 words, in plain declarative sentences, before
  going into brand story, marketing copy, or extended context.
- Use headers phrased as actual questions a buyer would type ("Is collagen powder safe during
  pregnancy?" not "Collagen Safety Info"), since these match query phrasing directly.
- Every substantive article or product page should carry an FAQ block of at least 5-8 questions,
  each answered in 50-150 words — long enough to be complete, short enough to lift cleanly.

## 2. Technical and structured data requirements

Models (and the crawlers/retrieval systems behind AI answers) need the page to be technically
legible, not just well-written:

- HTTPS, solid Core Web Vitals, mobile-friendly, and actually indexable (check robots.txt and
  meta robots tags aren't blocking useful pages).
- `FAQPage` schema on FAQ content, `Product` schema (price, availability, rating, review count)
  on product pages, `Review`/`AggregateRating` schema wherever real review data exists.
- Example minimal Product + FAQ schema to adapt:

```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Product Name",
  "description": "One or two sentence factual description of what it is and who it's for.",
  "brand": { "@type": "Brand", "name": "Brand Name" },
  "offers": {
    "@type": "Offer",
    "price": "29.99",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.7",
    "reviewCount": "312"
  }
}
```

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Exact buyer question, phrased how they'd actually type it",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Direct, complete answer in 50-150 words."
      }
    }
  ]
}
```

Never fabricate rating values, review counts, or availability data when generating schema for a
real brand — pull the real numbers from the user or leave a placeholder clearly marked for them
to fill in.

## 3. Comparison content

Buyers frequently ask models to compare options, and models answer comparison questions by
finding pages that already lay out the comparison rather than synthesizing one from scratch.
Brands that never publish comparison content are ceding this entirely to whoever does (often a
competitor, or a third-party "best X" roundup that may not even carry them).

Effective comparison content directly names alternatives and is honest about tradeoffs — a page
that's transparently one-sided reads as marketing copy and both buyers and models discount it.
Cover: what's different, what each option is actually best for, and what kind of buyer should
pick which. If a competitor genuinely wins on some dimension (price, availability, a specific use
case), say so; it builds the credibility that makes the rest of the page trustworthy.

## 4. Third-party proof and citation building

Self-published brand content is a weaker signal than independent sources saying the same thing.
Models weight answers more heavily when multiple independent sources agree, especially sources
outside the brand's own domain:

- **Reviews and UGC**: genuine customer reviews, especially detailed ones on the brand's own
  site *and* on third-party platforms (Trustpilot, category-specific review sites, Reddit
  threads, forums relevant to the category).
- **Digital PR / earned coverage**: getting mentioned in publications a model is likely to have
  ingested and trust (trade press, category authority sites — not necessarily massive outlets;
  category-specific relevance often matters more than raw domain authority).
- **Original data**: a brand that publishes original research, survey data, or a genuinely useful
  data point in its category becomes something other sources cite, which compounds — citation
  chains are a strong GEO signal and hard for competitors to replicate quickly.
- **Named, credentialed authors**: bylines from a real person with relevant expertise (and an
  external presence — LinkedIn, published elsewhere) read as more trustworthy than anonymous
  "Team" bylines, both to models and to human readers doing their own verification.
- **Reddit and forums specifically**: DTC categories in particular get pulled into AI answers via
  Reddit threads and niche forums quite often. This isn't about astroturfing — it's about
  genuinely participating (founder or team members answering real questions honestly) in the
  communities where buyers already discuss the category, and about knowing that a bad or absent
  Reddit presence when competitors have a good one is a real, measurable gap.

## 5. Measurement

- Track AI referral traffic in analytics (filter for chatgpt.com, perplexity.ai,
  gemini.google.com, and similar referrers) to see whether AI-driven traffic exists and where it
  lands.
- Rerun a consistent set of buyer-intent prompts across engines on a regular cadence (monthly is
  reasonable for a small team) and log: mentioned or not, position/framing, what sources the
  answer cited. This skill's `scripts/build_tracker.py` generates a starting prompt set.
- Watch competitor presence in the same answers, not just the brand's own presence — a brand
  that's absent while three competitors are consistently named has a different problem (and
  usually a more urgent one) than a brand that's present but described inaccurately.
