# Site/content audit checklist

Use this to score the brand's own site during Step 1B of the audit. For each category, note
what's actually true of the pages you fetched — don't guess at pages you haven't looked at. A
brand can be strong on some categories and weak on others; the point is to find the specific
gaps, not to produce a single number.

## Content structure
- [ ] Product/category pages answer "what is it, who's it for, what problem does it solve" in
      the first few hundred words, not buried under brand story or hero copy
- [ ] Headers are phrased as real buyer questions where relevant
- [ ] FAQ sections exist on product and key category pages, with 5+ questions each
- [ ] FAQ answers are complete and self-contained (would make sense lifted out of context)

## Comparison and decision content
- [ ] Any page exists that names real alternatives/competitors and compares against them
- [ ] Comparison content is even-handed enough to be credible (not pure marketing copy)
- [ ] Content answers "who should choose this vs. an alternative" rather than only "why we're
      the best"

## Structured data / technical
- [ ] Product schema present on product pages (check page source or a schema validator)
- [ ] FAQPage schema present on FAQ content
- [ ] Review/AggregateRating schema present where real review data exists
- [ ] Site is indexable (no robots.txt or meta-robots blocks on important pages), HTTPS, and
      reasonably fast/mobile-friendly

## Third-party proof
- [ ] Genuine customer reviews visible on-site
- [ ] Presence on third-party review platforms relevant to the category
- [ ] Any earned press/PR coverage in publications relevant to the category
- [ ] Any organic presence in Reddit threads or forums relevant to the category (search for the
      brand name + category terms on Reddit to check, don't assume)
- [ ] Original data, research, or a genuinely citable resource published anywhere on the site

## Authorship / credibility signals
- [ ] Content has named authors/contributors rather than anonymous "Team" bylines, where
      relevant (blog/education content especially)
- [ ] Claims made on-site (certifications, sourcing, testing) are specific and verifiable rather
      than vague superlatives
