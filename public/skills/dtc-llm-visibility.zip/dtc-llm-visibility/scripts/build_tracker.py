#!/usr/bin/env python3
"""
Generate a starter CSV of buyer-intent test prompts for tracking a DTC brand's
visibility across AI engines (ChatGPT, Claude, Perplexity, Gemini).

The prompt patterns mirror the live-query test in SKILL.md Step 1, so the audit
and the ongoing tracker stay consistent with each other.

Usage:
    python build_tracker.py --brand "BrandName" --category "electrolyte powders" \
        --competitors "Competitor A,Competitor B,Competitor C" --output tracker.csv

The output CSV has one row per (prompt x engine) so the user can fill in results
each time they rerun it. Re-running this script does NOT query any AI engines
itself -- it only generates the prompt list and the tracking columns. Actually
testing the prompts against each engine is manual (or done live by Claude during
an audit), and should be noted as such to the user.
"""

import argparse
import csv
import datetime

ENGINES = ["Claude", "ChatGPT", "Perplexity", "Gemini"]

PROMPT_TEMPLATES = [
    "What's the best {category} for {audience}?",
    "What's the best {category}?",
    "{brand} vs {competitor_1} vs {competitor_2} — which is better?",
    "Is {brand} worth it?",
    "What are good alternatives to {competitor_1}?",
    "Best {category} for beginners",
    "Most affordable good-quality {category}",
    "What {category} do people recommend on Reddit?",
    "{competitor_1} vs {brand}",
    "Top {category} brands in {year}",
]


def build_prompts(brand, category, competitors, audience, year):
    competitor_1 = competitors[0] if len(competitors) > 0 else "a competitor"
    competitor_2 = competitors[1] if len(competitors) > 1 else "another option"
    prompts = []
    for template in PROMPT_TEMPLATES:
        try:
            prompt = template.format(
                brand=brand,
                category=category,
                audience=audience,
                competitor_1=competitor_1,
                competitor_2=competitor_2,
                year=year,
            )
        except (KeyError, IndexError):
            continue
        prompts.append(prompt)
    # de-dupe while preserving order (short competitor lists can create repeats)
    seen = set()
    unique_prompts = []
    for p in prompts:
        if p not in seen:
            seen.add(p)
            unique_prompts.append(p)
    return unique_prompts


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--brand", required=True, help="Brand name, e.g. 'Nectar'")
    parser.add_argument("--category", required=True, help="Product category, e.g. 'electrolyte powders'")
    parser.add_argument("--competitors", default="", help="Comma-separated competitor names")
    parser.add_argument("--audience", default="everyday use", help="Target buyer description, e.g. 'athletes'")
    parser.add_argument("--output", default="tracker.csv", help="Output CSV path")
    args = parser.parse_args()

    competitors = [c.strip() for c in args.competitors.split(",") if c.strip()]
    year = datetime.date.today().year

    prompts = build_prompts(args.brand, args.category, competitors, args.audience, year)

    with open(args.output, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "date_tested", "prompt", "engine", "brand_mentioned (y/n)",
            "position/framing", "competitors_mentioned", "source_cited", "notes",
        ])
        for prompt in prompts:
            for engine in ENGINES:
                writer.writerow(["", prompt, engine, "", "", "", "", ""])

    print(f"Wrote {len(prompts)} prompts x {len(ENGINES)} engines = "
          f"{len(prompts) * len(ENGINES)} rows to {args.output}")
    print("Fill in results by running each prompt against each engine and logging what you see.")
    print("Hand this CSV to the xlsx skill to turn it into a spreadsheet, or use it as-is.")


if __name__ == "__main__":
    main()
